public class RDParserException extends Exception {
    public RDParserException(String msg) {
        super(msg);
    }
}
