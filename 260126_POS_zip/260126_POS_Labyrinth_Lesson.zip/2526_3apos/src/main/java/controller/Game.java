package controller;

import lombok.extern.java.Log;

import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

@Log
public class Game extends BaseGame {

    @Override
    public void update() {
        log.info("--> game update called");
    }

    @Override
    public void draw() {
        log.info("--> game draw called");
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        log.info("--> game mouseClicked called");

    }

    @Override
    public void mouseDown(MouseEvent e) {
        log.info("--> game mouseDown called");

    }

    @Override
    public void mouseRelease(MouseEvent e) {
        log.info("--> game mouseRelease called");

    }

    @Override
    public void keyPressed(KeyEvent e) {
        log.info("--> game keyPressed called " + e.getKeyChar());
    }

}
