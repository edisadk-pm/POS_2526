import algo.Search;
import gui.Labyrinth;
import utils.Location;
import utils.Node;
import utils.Path;

import java.util.List;

public class Game {
    public static void main(String[] args) {
        int rows = 20;
        int cols = 100;
        float spread = 0.3f;
        Location start = new Location(1, 1);
        Location goal = new Location(rows-1, cols-2);
        Labyrinth labyrinth = new Labyrinth(rows, cols, start, goal, spread);

        Node result = Search.bfs(start, labyrinth);
        //Node result = Search.dfs(start, labyrinth);
        if(result != null) {
            List<Location> path = Path.generate(result);

            labyrinth.setPath(path);

            System.out.println(labyrinth);
        } else {
            System.out.println("No Result found");
        }

    }
}
