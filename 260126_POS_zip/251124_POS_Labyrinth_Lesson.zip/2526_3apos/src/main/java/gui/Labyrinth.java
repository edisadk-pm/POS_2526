package gui;

import utils.Location;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Labyrinth {
    private int rows;
    private int cols;
    private Cell[][] grid;
    private Location start;
    private Location goal;
    private float spread;

    public Labyrinth(int rows, int cols,
                     Location start, Location goal, float spread){
        this.rows = rows;
        this.cols = cols;

        this.start = start;
        this.goal = goal;

        this.spread = spread;

        grid = new Cell[rows][cols];
        // 1 your turn: init the grid
        for(int r = 0; r < this.rows; r++){
            for(int c = 0; c < this.cols; c++){
                grid[r][c] = new Cell();
            }
        }

        // your turn: insert the obstacles ...
        fillWithObstacles();

        // your turn: set start / goal into the labyrinth
        grid[start.row][start.col].setState("S");
        grid[goal.row][goal.col].setState("G");

    }

    private void fillWithObstacles(){
        Random random = new Random();
        for(int r = 0; r < rows; r++){
            for(int c = 0; c < cols; c++){
                float randomSpread = random.nextFloat(); // gleich verteilt
                if(randomSpread < this.spread){
                    grid[r][c].setState("X");
                }
            }
        }
    }

    public boolean isGoal(Location location){
        return goal.compareTo(location) == 0;
    }

    public List<Location> getNeighbours(Location location){
        List<Location> result = new ArrayList<>();

        // your turn: find all valid neigbours from location
        // oben
        if(location.row - 1 >= 0 &&
                grid[location.row - 1][location.col].getState() != "X"){
            result.add(new Location(location.row - 1, location.col));
        }

        // unten
        if(location.row + 1 < this.rows &&
                grid[location.row + 1][location.col].getState() != "X"){
            result.add(new Location(location.row + 1, location.col));
        }

        // links
        if(location.col - 1 >= 0 &&
                grid[location.row][location.col - 1].getState() != "X"){
            result.add(new Location(location.row, location.col - 1));
        }

        // rechts
        if(location.col + 1 < this.cols &&
                grid[location.row][location.col + 1].getState() != "X"){
            result.add(new Location(location.row, location.col + 1));
        }

        return result;
    }

    public void setPath(List<Location> path){
        for(Location l : path){
            grid[l.row][l.col].setState("*");
        }
        // your turn: set start / goal into the labyrinth
        grid[start.row][start.col].setState("S");
        grid[goal.row][goal.col].setState("G");
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();

        for(int r = 0; r < this.rows; r++){
            for(int c = 0; c < this.cols; c++){
                sb.append(grid[r][c].toString());
            }
            sb.append("\n");
        }

        return sb.toString();
    }
}
