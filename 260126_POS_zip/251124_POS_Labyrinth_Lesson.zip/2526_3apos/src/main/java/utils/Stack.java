package utils;

import java.util.ArrayList;
import java.util.List;

public class Stack implements DataStructure {
    // How a Stack works?
    // push ... add an element
    // pop ... get the last element and remove
    // isEmpty ... true if empty otherwise false

    private List<Node> container;

    public Stack(){
        container = new ArrayList<>();
    }

    public void push(Node e){
        container.add(e);
    }

    public Node pop(){
        //Node exNode = container.get(container.size()-1);
        Node node = container.removeLast(); // pop für List<>
        return node;
    }

    public boolean isEmpty(){
        return container.isEmpty();
    }

    public static void main(String[] args) {
        Stack stack = new Stack();
        Node node = new Node(null, new Location(1, 2));
        stack.push(node);
        System.out.println("False " + stack.isEmpty());
        stack.pop();
        System.out.println("True " + stack.isEmpty());

    }
}
