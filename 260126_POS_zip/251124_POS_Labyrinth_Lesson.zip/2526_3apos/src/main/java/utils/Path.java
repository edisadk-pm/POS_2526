package utils;

import java.util.ArrayList;
import java.util.List;

public class Path {
    public static List<Location> generate(Node node){
        List<Location> path = new ArrayList<>();

        Node currentNode = node.getParent();
        while(currentNode.getParent() != null){
            path.add(currentNode.getData());
            currentNode = currentNode.getParent();
        }

        return path;
    }
}
