package utils;

public interface DataStructure {
    void push(Node e);
    Node pop();
    boolean isEmpty();
}
