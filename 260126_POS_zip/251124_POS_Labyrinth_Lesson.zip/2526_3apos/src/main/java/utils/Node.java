package utils;

public class Node {
    // What a node need?
    // parent
    // information -> data

    private Node parent;
    private Location data;

    public Node(Node parent, Location data){
        this.parent = parent;
        this.data = data;
    }

    public Node getParent() {
        return parent;
    }

    public Location getData() {
        return data;
    }

    @Override
    public String toString() {
        return "Node" + data.toString();
    }
}
