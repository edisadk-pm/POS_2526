package utils;

import java.util.ArrayList;
import java.util.List;

public class Queue implements DataStructure{
    private List<Node> container;
    public Queue(){
        container = new ArrayList<>();
    }

    public Node pop(){
        return container.removeFirst();
    }

    public void push(Node node){
        container.add(node);
    }

    public boolean isEmpty(){
        return container.isEmpty();
    }
}
