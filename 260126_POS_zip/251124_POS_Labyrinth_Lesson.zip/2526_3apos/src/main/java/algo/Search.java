package algo;

import gui.Labyrinth;
import utils.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Search {
    // Depth First Search
    public static Node dfs(Location start, Labyrinth grid){
        DataStructure frontiers = new Stack();
        return generic_search(start, grid, frontiers);
    }

    // Breadth First Search - Breitensuche
    public static Node bfs(Location start, Labyrinth grid){
        DataStructure frontiers = new Queue();
        return generic_search(start, grid, frontiers);
    }

    public static Node generic_search(Location start,
                                      Labyrinth grid,
                                      DataStructure frontiers){
        // 0.) init: prepare
        //Stack frontiers = new Stack();
        frontiers.push(new Node(null, start));

        // Homework
        Set<Location> visitedNodes = new HashSet<>(); // liste, aber ohne Duplikate
//        List<Location> visitedNodes = new ArrayList<>();

        while(!frontiers.isEmpty()) {
            // 1.) get current node/location from stack
            Node currentNode = frontiers.pop();
            Location currentLocation = currentNode.getData();

            // 2.) ask
            if(grid.isGoal(currentLocation)){
                return currentNode;
            }

            // 3.) get neighbours from location and push
            List<Location> neighbours = grid.getNeighbours(currentLocation);
            for(Location neighbour : neighbours){

                if(visitedNodes.contains(neighbour)){
                    continue;
                }
                visitedNodes.add(neighbour);
                frontiers.push(new Node(currentNode, neighbour));
            }

        }

        // ende of methode - >nothing found
        return null;
    }
}
